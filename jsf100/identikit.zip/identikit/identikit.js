// coordinate variables
let eye_left_x = 100;
let eye_left_y = 100;
let eye_right_x = 250;
let eye_right_y = 100;

// set initial positions
document.querySelector('#eye_left').style.left = eye_left_x + 'px';
document.querySelector('#eye_left').style.top = eye_left_y + 'px';
document.querySelector('#eye_right').style.left = eye_right_x + 'px';
document.querySelector('#eye_right').style.top = eye_right_y + 'px';

/*
// move eyes up event listener
document.querySelector('#eyes_up_btn').addEventListener('click', () => {
  eye_left_y -= 10;
  document.querySelector('#eye_left').style.top = eye_left_y + 'px';
  eye_right_y -= 10;
  document.querySelector('#eye_right').style.top = eye_right_y + 'px';
});
*/
